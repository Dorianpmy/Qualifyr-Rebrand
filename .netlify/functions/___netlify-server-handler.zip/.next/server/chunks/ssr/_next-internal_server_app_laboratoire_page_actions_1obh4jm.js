module.exports=[87463,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_laboratoire_page_actions_1obh4jm.js.map