module.exports=[55060,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_diagnostic_page_actions_1wwnz4c.js.map