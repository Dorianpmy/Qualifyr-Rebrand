module.exports=[66322,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_creation-site-web_page_actions_1oacf8_.js.map