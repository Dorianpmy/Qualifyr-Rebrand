module.exports=[37819,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_realisations_sw-car-cleaning_page_actions_0xwask8.js.map