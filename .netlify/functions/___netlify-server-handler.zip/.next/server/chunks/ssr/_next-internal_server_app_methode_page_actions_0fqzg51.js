module.exports=[58923,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_methode_page_actions_0fqzg51.js.map