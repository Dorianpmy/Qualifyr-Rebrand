module.exports=[92878,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_politique-de-confidentialite_page_actions_0uibwjo.js.map