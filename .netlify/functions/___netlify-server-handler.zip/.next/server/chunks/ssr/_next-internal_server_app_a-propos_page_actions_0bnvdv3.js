module.exports=[56158,a=>{"use strict";a.s([])}];

//# sourceMappingURL=_next-internal_server_app_a-propos_page_actions_0bnvdv3.js.map