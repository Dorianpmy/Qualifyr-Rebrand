module.exports=[98196,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_go_%5Bcampaign%5D_route_actions_1ntwfy-.js.map