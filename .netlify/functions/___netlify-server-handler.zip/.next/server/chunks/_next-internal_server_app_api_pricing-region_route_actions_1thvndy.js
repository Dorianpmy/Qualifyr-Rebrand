module.exports=[86054,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_pricing-region_route_actions_1thvndy.js.map