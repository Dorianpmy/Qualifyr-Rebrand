var R=require("../../chunks/[turbopack]_runtime.js")("server/app/llms.txt/route.js")
R.c("server/chunks/[root-of-the-server]__17ly-3u._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_llms_txt_route_actions_09lmvgw.js")
R.m(69569)
module.exports=R.m(69569).exports
