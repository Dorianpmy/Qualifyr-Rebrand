var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/go/[campaign]/route.js")
R.c("server/chunks/[root-of-the-server]__1dq4wwo._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/_next-internal_server_app_go_[campaign]_route_actions_1ntwfy-.js")
R.m(83636)
module.exports=R.m(83636).exports
