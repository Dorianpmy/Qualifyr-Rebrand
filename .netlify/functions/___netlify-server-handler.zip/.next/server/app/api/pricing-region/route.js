var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/pricing-region/route.js")
R.c("server/chunks/[root-of-the-server]__11-z_as._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_pricing-region_route_actions_1thvndy.js")
R.m(13254)
module.exports=R.m(13254).exports
