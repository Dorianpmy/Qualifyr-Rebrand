var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/diagnostic/route.js")
R.c("server/chunks/[root-of-the-server]__1z1vuvz._.js")
R.c("server/chunks/src_lib_email_submission_ts_0gh0brm._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_api_diagnostic_route_actions_04lug44.js")
R.m(7641)
module.exports=R.m(7641).exports
