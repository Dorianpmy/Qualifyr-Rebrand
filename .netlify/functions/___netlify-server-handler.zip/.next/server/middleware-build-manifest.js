globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/u4iy-tINB9gGxpG8ItJHJ/_buildManifest.js",
    "static/u4iy-tINB9gGxpG8ItJHJ/_ssgManifest.js",
    "static/u4iy-tINB9gGxpG8ItJHJ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0iq1i69206cyl.js",
    "static/chunks/27jktro2p5rq9.js",
    "static/chunks/2-5nk792mwq2y.js",
    "static/chunks/1upe53-127sm4.js",
    "static/chunks/turbopack-0fo5_pvlhgzo7.js"
  ]
};
